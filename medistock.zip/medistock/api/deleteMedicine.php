<?php
header('Content-Type: application/json');
require_once __DIR__ . '/dbconnect.php';

$db = require __DIR__ . '/dbconnect.php';
$collection = $db->selectCollection('medicines');

$id = $_GET['id'] ?? null;

if (!$id) {
    echo json_encode(['success' => false, 'message' => 'Medicine ID required']);
    exit;
}

try {

    $result = $collection->deleteOne([
        '_id' => new MongoDB\BSON\ObjectId($id)
    ]);

    // ⭐ Firebase update trigger
    file_get_contents("https://medicalinventory-63b43-default-rtdb.firebaseio.com/realtime_updates/medicines.json",
        false,
        stream_context_create([
            'http' => [
                'method' => 'PUT',
                'header' => 'Content-Type: application/json',
                'content' => json_encode(["updatedAt" => time()])
            ]
        ])
    );

    echo json_encode(['success' => true]);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
