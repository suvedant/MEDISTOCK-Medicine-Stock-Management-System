<?php
header('Content-Type: text/html; charset=utf-8');
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>
<!DOCTYPE html>
<html>
<head>
    <title>MongoDB Connection Test</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        h1 { color: #333; }
        .success { color: #28a745; background: #d4edda; padding: 10px; border-radius: 4px; margin: 10px 0; }
        .error { color: #dc3545; background: #f8d7da; padding: 10px; border-radius: 4px; margin: 10px 0; }
        .info { color: #004085; background: #d1ecf1; padding: 10px; border-radius: 4px; margin: 10px 0; }
        pre { background: #f8f9fa; padding: 10px; border-radius: 4px; overflow-x: auto; }
    </style>
</head>
<body>
    <div class="container">
        <h1>MongoDB Connection Test</h1>
        <?php
        require_once __DIR__ . '/../vendor/autoload.php';

        use MongoDB\Client;

        $connectionString = "mongodb://localhost:27017";
        $databaseName = "medicine_inventory";

        try {
            echo '<div class="info">Attempting to connect to MongoDB at ' . $connectionString . '...</div>';
            
            $client = new Client($connectionString);
            echo '<div class="success">✓ Client created successfully!</div>';
            
            // Test connection by listing databases
            $databases = $client->listDatabases();
            echo '<div class="success">✓ Connected! Available databases:</div>';
            echo '<pre>';
            foreach ($databases as $database) {
                echo "- " . $database->getName() . "\n";
            }
            echo '</pre>';
            
            // Select the database
            $db = $client->selectDatabase($databaseName);
            echo '<div class="info">Selected database: <strong>' . $databaseName . '</strong></div>';
            
            // Try to insert a test document
            $collection = $db->selectCollection('test_collection');
            $result = $collection->insertOne([
                'test' => 'connection', 
                'timestamp' => new MongoDB\BSON\UTCDateTime()
            ]);
            
            echo '<div class="success">✓ Test insert successful! Inserted ID: ' . $result->getInsertedId() . '</div>';
            
            // Clean up test document
            $collection->deleteOne(['_id' => $result->getInsertedId()]);
            echo '<div class="info">Test document cleaned up.</div>';
            
            echo '<div class="success"><strong>✅ MongoDB connection is working correctly!</strong></div>';
            
        } catch (Exception $e) {
            echo '<div class="error">';
            echo '<strong>❌ Error:</strong> ' . htmlspecialchars($e->getMessage()) . '<br>';
            echo '<strong>File:</strong> ' . htmlspecialchars($e->getFile()) . '<br>';
            echo '<strong>Line:</strong> ' . $e->getLine();
            echo '</div>';
        }
        ?>
    </div>
</body>
</html>

