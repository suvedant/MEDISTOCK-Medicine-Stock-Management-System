<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

error_reporting(E_ALL);
ini_set('display_errors', 0);

$db = require __DIR__ . '/dbconnect.php';
$collection = $db->selectCollection('medicines');

$data = json_decode(file_get_contents('php://input'), true);

// Check required fields
if (!isset($data['name']) || !isset($data['category']) || !isset($data['qty']) || !isset($data['price'])) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit;
}

try {
    // Insert into MongoDB
    $result = $collection->insertOne([
        'name' => $data['name'],
        'category' => $data['category'],
        'qty' => (int)$data['qty'],
        'price' => (float)$data['price'],
        'created_at' => new MongoDB\BSON\UTCDateTime()
    ]);

    if ($result->getInsertedId()) {

        /* -----------------------------------------
           ⭐ FIREBASE REALTIME DATABASE UPDATE
        ------------------------------------------*/
        $updateData = [
            "timestamp" => time(),
            "action"    => "medicine_added",
            "medicine"  => $data['name']
        ];

        // Send update to Firebase
        $firebaseURL = "https://medicalinventory-63b43-default-rtdb.firebaseio.com/realtime_updates/medicines.json";

        $options = [
            "http" => [
                "method"  => "PUT",
                "header"  => "Content-Type: application/json",
                "content" => json_encode($updateData)
            ]
        ];

        $context = stream_context_create($options);
        file_get_contents($firebaseURL, false, $context);

        /* ------------------------------------------*/

        echo json_encode([
            'success' => true,
            'id' => (string)$result->getInsertedId()
        ]);

    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to insert data']);
    }

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
        'error' => $e->getFile() . ':' . $e->getLine()
    ]);
}

?>
