<?php
header('Content-Type: application/json');
require_once __DIR__ . '/dbconnect.php';

$db = require __DIR__ . '/dbconnect.php';
$ordersCollection = $db->selectCollection('orders');
$medicinesCollection = $db->selectCollection('medicines');

$data = json_decode(file_get_contents('php://input'), true);

try {

    $medicine = $medicinesCollection->findOne([
        '_id' => new MongoDB\BSON\ObjectId($data['medicineId'])
    ]);

    if (!$medicine) {
        echo json_encode(['success' => false, 'message' => 'Medicine not found']);
        exit;
    }

    if ($medicine['qty'] < $data['quantity']) {
        echo json_encode(['success' => false, 'message' => 'Not enough stock']);
        exit;
    }

    $order = [
        "medicineId" => $data["medicineId"],
        "medicineName" => $medicine["name"],
        "quantity" => (int)$data["quantity"],
        "price" => (float)$data["price"],
        "status" => "Pending",

        // Customer Info
        "customerId" => $data["customerId"],
        "customerName" => $data["customerName"],
        "customerEmail" => $data["customerEmail"],

        "created_at" => new MongoDB\BSON\UTCDateTime()
    ];

    // Insert Order
    $result = $ordersCollection->insertOne($order);

    // Reduce stock
    $medicinesCollection->updateOne(
        ['_id' => new MongoDB\BSON\ObjectId($data["medicineId"])],
        ['$inc' => ['qty' => -$data["quantity"]]]
    );

    // ⭐ Firebase order trigger
    file_get_contents("https://medicalinventory-63b43-default-rtdb.firebaseio.com/realtime_updates/orders.json",
        false,
        stream_context_create([
            'http' => [
                'method' => 'PUT',
                'header' => 'Content-Type: application/json',
                'content' => json_encode(["updatedAt" => time()])
            ]
        ])
    );

    echo json_encode(['success' => true, 'orderId' => (string)$result->getInsertedId()]);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
