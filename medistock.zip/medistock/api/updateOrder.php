<?php
header('Content-Type: application/json');
require_once __DIR__ . '/dbconnect.php';

$db = require __DIR__ . '/dbconnect.php';
$collection = $db->selectCollection('orders');

$data = json_decode(file_get_contents('php://input'), true);

try {

    $collection->updateOne(
        ['_id' => new MongoDB\BSON\ObjectId($data['id'])],
        ['$set' => [
            'status' => $data['status'],
            'updated_at' => new MongoDB\BSON\UTCDateTime()
        ]]
    );

    // ⭐ Update customer notification
    file_get_contents("https://medicalinventory-63b43-default-rtdb.firebaseio.com/order_notifications/{$data['id']}.json",
        false,
        stream_context_create([
            'http' => [
                'method' => 'PUT',
                'header' => 'Content-Type: application/json',
                'content' => json_encode([
                    "status" => $data['status'],
                    "timestamp" => time()
                ])
            ]
        ])
    );

    // ⭐ Update admin order table
    file_get_contents("https://medicalinventory-63b43-default-rtdb.firebaseio.com/realtime_updates/orders.json",
        false,
        stream_context_create([
            'http' => [
                'method' => 'PUT',
                'header' => 'Content-Type: application/json',
                'content' => json_encode(["updatedAt" => time()])
            ]
        ])
    );

    echo json_encode(['success' => true]);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
