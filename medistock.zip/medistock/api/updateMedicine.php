<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/dbconnect.php';

$db = require __DIR__ . '/dbconnect.php';
$collection = $db->selectCollection('medicines');

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['id'])) {
    echo json_encode(['success' => false, 'message' => 'Medicine ID required']);
    exit;
}

try {
    $updateData = [
        'updated_at' => new MongoDB\BSON\UTCDateTime()
    ];

    if (isset($data['name'])) $updateData['name'] = $data['name'];
    if (isset($data['category'])) $updateData['category'] = $data['category'];
    if (isset($data['qty'])) $updateData['qty'] = (int)$data['qty'];
    if (isset($data['price'])) $updateData['price'] = (float)$data['price'];

    $result = $collection->updateOne(
        ['_id' => new MongoDB\BSON\ObjectId($data['id'])],
        ['$set' => $updateData]
    );

    // ⭐ Firebase Update Trigger
    file_get_contents("https://medicalinventory-63b43-default-rtdb.firebaseio.com/realtime_updates/medicines.json",
        false,
        stream_context_create([
            'http' => [
                'method' => 'PUT',
                'header' => 'Content-Type: application/json',
                'content' => json_encode(["updatedAt" => time()])
            ]
        ])
    );

    echo json_encode(['success' => true]);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
