<?php
header('Content-Type: application/json');
require_once __DIR__ . '/dbconnect.php';

$db = require __DIR__ . '/dbconnect.php';
$collection = $db->selectCollection('medicines');

try {
    // Aggregation Pipeline: $match and $group
    // This pipeline groups medicines by category and calculates total quantity and average price per category
    $pipeline = [
        // $match stage: Filter medicines with quantity > 0
        ['$match' => ['qty' => ['$gt' => 0]]],
        
        // $group stage: Group by category and calculate statistics
        ['$group' => [
            '_id' => '$category',
            'totalQuantity' => ['$sum' => '$qty'],
            'averagePrice' => ['$avg' => '$price'],
            'medicineCount' => ['$sum' => 1],
            'medicines' => ['$push' => [
                'name' => '$name',
                'qty' => '$qty',
                'price' => '$price'
            ]]
        ]],
        
        // Sort by total quantity descending
        ['$sort' => ['totalQuantity' => -1]]
    ];
    
    $result = $collection->aggregate($pipeline);
    
    $output = [];
    foreach ($result as $doc) {
        $output[] = [
            'category' => $doc['_id'],
            'totalQuantity' => $doc['totalQuantity'],
            'averagePrice' => round($doc['averagePrice'], 2),
            'medicineCount' => $doc['medicineCount'],
            'medicines' => $doc['medicines']
        ];
    }
    
    echo json_encode(['success' => true, 'data' => $output]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>

