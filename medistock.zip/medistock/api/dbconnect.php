<?php
require_once __DIR__ . '/../vendor/autoload.php';

use MongoDB\Client;

// MongoDB connection string
$connectionString = "mongodb://localhost:27017";
$databaseName = "medicine_inventory";

try {
    // Create MongoDB client connection
    $client = new Client($connectionString);
    
    // Select the database (will be created automatically on first insert)
    $db = $client->selectDatabase($databaseName);
    
    return $db;
} catch (Exception $e) {
    // Don't die, throw exception so calling code can handle it
    throw new Exception("MongoDB Connection Error: " . $e->getMessage());
}

