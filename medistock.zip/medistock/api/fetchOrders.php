<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/dbconnect.php';

$db = require __DIR__ . '/dbconnect.php';
$type = $_GET['type'] ?? 'orders';

try {

    /* ------------------------------
       ⭐ FETCH MEDICINES
    ------------------------------ */
    if ($type === 'medicines') {
        $collection = $db->selectCollection('medicines');
        $docs = $collection->find([], ['sort' => ['name' => 1]]);

        $output = [];

        foreach ($docs as $d) {
            $output[] = [
                "_id" => ["\$oid" => (string)$d["_id"]],
                "name" => $d["name"],
                "category" => $d["category"],
                "qty" => $d["qty"],
                "price" => $d["price"]
            ];
        }

        echo json_encode($output);
        exit;
    }

    /* ------------------------------
       ⭐ FETCH ORDERS
    ------------------------------ */
    $collection = $db->selectCollection('orders');
    $cursor = $collection->find([], ['sort' => ['created_at' => -1]]);

    $out = [];
    foreach ($cursor as $o) {
        $out[] = [
            "_id" => ["\$oid" => (string)$o["_id"]],
            "orderId" => (string)$o["_id"],

            // Medicine Info
            "medicineName" => $o["medicineName"],
            "quantity" => $o["quantity"],
            "price" => $o["price"],
            "status" => $o["status"],

            // ⭐ Correct Customer Fields
            "customerId" => $o["customerId"] ?? "Unknown",
            "customerName" => $o["customerName"] ?? "Unknown",
            "customerEmail" => $o["customerEmail"] ?? "Unknown",

            // Date
            "date" => $o["created_at"]->toDateTime()->format('Y-m-d H:i:s')
        ];
    }

    echo json_encode($out);

} catch (Exception $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>