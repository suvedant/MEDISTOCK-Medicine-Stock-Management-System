# Data Model Documentation - MediStock Application

## Overview
This document explains the data modeling choices made for the MediStock application, specifically the decision between embedded and referenced data models.

## Database Structure

### MongoDB Collections

#### 1. `medicines` Collection
**Structure:**
```json
{
  "_id": ObjectId("..."),
  "name": "Paracetamol",
  "category": "Tablet",
  "qty": 100,
  "price": 25.50,
  "created_at": ISODate("..."),
  "updated_at": ISODate("...")
}
```

**Model Choice: Embedded**
- **Justification:** Medicine data is self-contained and doesn't require references to other collections. Each medicine document contains all necessary information (name, category, quantity, price) in a single document. This approach provides:
  - Fast read operations (single document retrieval)
  - Simple queries without joins
  - Atomic updates to medicine information
  - Better performance for inventory management operations

#### 2. `orders` Collection
**Structure:**
```json
{
  "_id": ObjectId("..."),
  "medicineId": ObjectId("..."),
  "medicineName": "Paracetamol",
  "quantity": 5,
  "price": 25.50,
  "status": "Pending",
  "userId": "firebase_user_id",
  "created_at": ISODate("..."),
  "updated_at": ISODate("...")
}
```

**Model Choice: Hybrid (Referenced with Denormalization)**
- **Justification:** 
  - **Referenced:** Uses `medicineId` to reference the `medicines` collection, maintaining data integrity and allowing updates to medicine information without affecting historical orders.
  - **Denormalized:** Includes `medicineName` and `price` directly in the order document for:
    - **Performance:** Faster order retrieval without needing to join with medicines collection
    - **Historical Accuracy:** Preserves the medicine name and price at the time of order, even if medicine information changes later
    - **Query Efficiency:** Allows filtering and displaying orders without additional database queries

**Why Not Fully Embedded?**
- If we fully embedded medicine data in orders, we would face:
  - Data duplication (medicine details in every order)
  - Update complexity (updating medicine info would require updating all related orders)
  - Storage inefficiency (repeated medicine information)

**Why Not Fully Referenced?**
- If we only used references without denormalization:
  - Every order display would require a join operation
  - Slower query performance
  - More complex application logic

## Firebase Realtime Database Structure

### `realtime_updates` Node
**Structure:**
```json
{
  "realtime_updates": {
    "medicines": {
      "timestamp": 1234567890,
      "count": 50,
      "lastUpdate": "2024-01-01T12:00:00Z"
    },
    "orders": {
      "timestamp": 1234567890,
      "lastOrder": "Paracetamol",
      "lastUpdate": "2024-01-01T12:00:00Z"
    }
  }
}
```

**Model Choice: Embedded**
- **Justification:** Real-time update metadata is small, frequently accessed, and doesn't require complex relationships. Embedding provides:
  - Fast real-time synchronization
  - Simple listener setup
  - Minimal data transfer
  - Easy to update atomically

## Summary

| Collection/Node | Model Type | Reason |
|----------------|------------|--------|
| `medicines` | Embedded | Self-contained, fast reads, simple queries |
| `orders` | Hybrid (Referenced + Denormalized) | Data integrity + performance + historical accuracy |
| `realtime_updates` | Embedded | Small metadata, fast sync, simple structure |

## Best Practices Applied

1. **Embedded Model** - Used for:
   - Small, self-contained documents
   - Frequently accessed together
   - No need for complex relationships

2. **Referenced Model** - Used for:
   - Large documents that would cause duplication
   - Documents that change independently
   - One-to-many relationships

3. **Hybrid Model** - Used for:
   - Balancing performance and data integrity
   - Historical data preservation
   - Optimizing read operations while maintaining relationships

## Performance Considerations

- **Indexes Created:**
  - `name_index` on medicines.name - For fast medicine search
  - `category_index` on medicines.category - For category filtering
  - `category_price_index` compound index - For complex queries combining category and price

- **Query Optimization:**
  - Aggregation pipeline uses $match and $group for efficient analytics
  - Index usage verified with explain() for performance analysis
  - Real-time updates minimize unnecessary full data reloads

